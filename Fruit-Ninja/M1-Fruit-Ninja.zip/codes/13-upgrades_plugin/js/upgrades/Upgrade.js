var FruitNinja = FruitNinja || {};

FruitNinja.Upgrade = function (game_state) {
    "use strict";
    this.game_state = game_state;
};

FruitNinja.Upgrade.prototype.apply = function () {
    "use strict";
};